<template>
    <t-lock/>
</template>

<script>
import TLock from "@/Components/Auth/TLock.vue";

export default {
    components: {TLock}
}
</script>
