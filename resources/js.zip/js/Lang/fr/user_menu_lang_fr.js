const userMenuLangFr = {
    manageAccount: "Manage Account",
    manageTeam: "Manage Team",
    switchTeams: "Switch Team",
    language: "Language",
    darkMode: "Dark Mode",
    profile: "Profile",
    api: "API Tokens",
    teamSettings: "Team Settings",
    createNewTeam: "Create New Team",
    auto: "Auto",
    dark: "Dark",
    light: "Light",
    logout: "Logout"
};

export default userMenuLangFr;
