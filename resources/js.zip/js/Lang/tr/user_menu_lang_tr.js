const userMenuLangTr = {
    manageAccount: "Hesap Yönetimi",
    manageTeam: "Takım Yönetimi",
    switchTeams: "Takım Değiştir",
    language: "Dil",
    darkMode: "Koyu Mod",
    profile: "Profil",
    api: "API Anahtarları",
    teamSettings: "Takım Ayarları",
    createNewTeam: "Yeni Takım Oluştur",
    auto: "Otomatik",
    dark: "Koyu",
    light: "Açık",
    logout: "Çıkış"
};

export default userMenuLangTr;
