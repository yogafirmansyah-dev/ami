const notification_ = {
    pendingWorks: 'Bekleyen İşler',
    unfinishedTodos: 'Devam Eden Yapılacaklar',
    unreadMessages: 'Okunmamış Mesajlar'
};

export default notification_;
