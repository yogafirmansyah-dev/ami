const generalLangEn = {
    brandName: "LaraQuality",
    /* Theme */
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    auto: "Auto",
    /* Error */
    somethingWentWrong: "Oops, Something went wrong",
    /* Simple Terms */
    save: 'Save',
    reset: 'Reset',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    view: 'View'
};

export default generalLangEn;
