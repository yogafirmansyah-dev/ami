const pagination_en = {
    detailText: "{totalPage} pages - {totalRecord} records",
    previous: "Previous",
    next: "Next",
}
export default pagination_en
