const notification_ru = {
    pendingWorks: 'Ожидающие работы',
    unfinishedTodos: 'Текущие дела',
    unreadMessages: 'Непрочитанные сообщения'
};

export default notification_ru;
