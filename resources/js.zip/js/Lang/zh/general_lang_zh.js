const generalLangZh = {
    brandName: "LaraQuality",
    /* Theme */
    darkMode: "黑暗主题",
    lightMode: "轻主题",
    auto: "自动的",
    /* Error */
    somethingWentWrong: "哎呀！出事了",
    /* Simple Terms */
    save: '保存',
    reset: '重启',
    cancel: '取消',
    delete: '删除',
    edit: '编辑',
    view: '看法'
};

export default generalLangZh;
