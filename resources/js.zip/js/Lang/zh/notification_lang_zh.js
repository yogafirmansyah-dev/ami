const notification_zh = {
    pendingWorks: '待定作品',
    unfinishedTodos: '正在进行的待办事项',
    unreadMessages: '未读消息'
};

export default notification_zh;
