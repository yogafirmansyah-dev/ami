import { createPinia } from 'pinia'

export default ()=>{
    const pinia = createPinia()

    return pinia
}
