<template>
    <app-layout title="Terms & Conditions">
        <div class="max-w-3xl mx-auto py-12 px-6">
            <h1 class="text-3xl font-bold mb-6">Terms & Conditions</h1>
            <div class="prose dark:prose-invert">
                <p>
                    Welcome to our Terms & Conditions page. Please read carefully.
                </p>
                <h2>Section 1: Usage</h2>
                <p>
                    You must agree to these terms to use our service.
                </p>
                <h2>Section 2: Privacy</h2>
                <p>
                    Your privacy is important to us. Please review our policy.
                </p>
                <!-- Daha fazla bölüm ekleyebilirsiniz -->
            </div>
        </div>
    </app-layout>
</template>

<script setup>
import AppLayout from '@/Layouts/AppLayout.vue'
</script>
