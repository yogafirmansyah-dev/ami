<template>
    <app-layout title="Privacy Policy">
        <div class="max-w-3xl mx-auto py-12 px-6">
            <h1 class="text-3xl font-bold mb-6">Privacy Policy</h1>
            <div class="prose dark:prose-invert">
                <p>
                    Welcome to our Privacy Policy page. Please read carefully.
                </p>
                <h2>Section 1: Data Collection</h2>
                <p>
                    We collect personal data to provide and improve our services.
                </p>
                <h2>Section 2: Data Usage</h2>
                <p>
                    Your data is used in accordance with this policy and applicable laws.
                </p>
                <!-- Daha fazla bölüm ekleyebilirsiniz -->
            </div>
        </div>
    </app-layout>
</template>

<script setup>
import AppLayout from '@/Layouts/AppLayout.vue'
</script>
