<template>
  <app-layout>
    <template #header>TO-DO Application</template>
    <template #subHeader></template>
    <template #default>

    </template>
  </app-layout>
</template>

<script>
import AppLayout from "@/Layouts/AppLayout.vue";

export default {
  name: "TodoApp",
  components: {AppLayout}
}
</script>

<style scoped>

</style>
