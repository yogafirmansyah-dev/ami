<template>
  <app-layout>
    <template #header>Profile Page</template>
    <template #subHeader>User page</template>
    <template #default>

    </template>
  </app-layout>
</template>

<script>
import AppLayout from "@/Layouts/AppLayout.vue";

export default {
  name: "Profile",
  components: {AppLayout}
}
</script>

<style scoped>

</style>
