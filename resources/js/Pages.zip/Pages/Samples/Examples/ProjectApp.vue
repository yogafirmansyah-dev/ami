<template>
  <app-layout>
    <template #header>Project Application Page</template>
    <template #subHeader></template>
    <template #default>

    </template>
  </app-layout>
</template>

<script>
import AppLayout from "@/Layouts/AppLayout.vue";

export default {
  name: "ProjectApp",
  components: {AppLayout}
}
</script>

<style scoped>

</style>
